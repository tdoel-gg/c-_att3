#pragma once

#include <cstddef>
#include <utility>

template <typename Key, typename Value>
class AssocArray {
private:
    struct Entry {
        Key key;
        Value value;
    };

    Entry* m_data;
    std::size_t m_size;
    std::size_t m_capacity;

    static constexpr std::size_t npos = static_cast<std::size_t>(-1);

    std::size_t findIndex(const Key& key) const {
        for (std::size_t i = 0; i < m_size; ++i) {
            if (m_data[i].key == key) {
                return i;
            }
        }
        return npos;
    }

    void grow() {
        std::size_t newCapacity = m_capacity == 0 ? 2 : m_capacity * 2;
        Entry* newData = new Entry[newCapacity];
        for (std::size_t i = 0; i < m_size; ++i) {
            newData[i] = std::move(m_data[i]);
        }
        delete[] m_data;
        m_data = newData;
        m_capacity = newCapacity;
    }

public:
    AssocArray()
        : m_data(nullptr), m_size(0), m_capacity(0) {}

    ~AssocArray() {
        delete[] m_data;
    }

    AssocArray(const AssocArray& other)
        : m_data(nullptr), m_size(other.m_size), m_capacity(other.m_capacity) {
        if (m_capacity > 0) {
            m_data = new Entry[m_capacity];
            for (std::size_t i = 0; i < m_size; ++i) {
                m_data[i] = other.m_data[i];
            }
        }
    }

    AssocArray(AssocArray&& other) noexcept
        : m_data(other.m_data), m_size(other.m_size), m_capacity(other.m_capacity) {
        other.m_data = nullptr;
        other.m_size = 0;
        other.m_capacity = 0;
    }

    AssocArray& operator=(const AssocArray& other) {
        if (this != &other) {
            delete[] m_data;
            m_size = other.m_size;
            m_capacity = other.m_capacity;
            m_data = nullptr;
            if (m_capacity > 0) {
                m_data = new Entry[m_capacity];
                for (std::size_t i = 0; i < m_size; ++i) {
                    m_data[i] = other.m_data[i];
                }
            }
        }
        return *this;
    }

    AssocArray& operator=(AssocArray&& other) noexcept {
        if (this != &other) {
            delete[] m_data;
            m_data = other.m_data;
            m_size = other.m_size;
            m_capacity = other.m_capacity;
            other.m_data = nullptr;
            other.m_size = 0;
            other.m_capacity = 0;
        }
        return *this;
    }

    std::size_t size() const noexcept {
        return m_size;
    }

    bool empty() const noexcept {
        return m_size == 0;
    }

    void insert(const Key& key, const Value& value) {
        std::size_t index = findIndex(key);
        if (index != npos) {
            m_data[index].value = value;
            return;
        }

        if (m_size >= m_capacity) {
            grow();
        }

        m_data[m_size++] = Entry{key, value};
    }

    bool contains(const Key& key) const {
        return findIndex(key) != npos;
    }

    Value* find(const Key& key) {
        std::size_t index = findIndex(key);
        return index != npos ? &m_data[index].value : nullptr;
    }

    const Value* find(const Key& key) const {
        std::size_t index = findIndex(key);
        return index != npos ? &m_data[index].value : nullptr;
    }

    bool erase(const Key& key) {
        std::size_t index = findIndex(key);
        if (index == npos) {
            return false;
        }
        for (std::size_t i = index; i + 1 < m_size; ++i) {
            m_data[i] = std::move(m_data[i + 1]);
        }
        --m_size;
        return true;
    }

    Value& operator[](const Key& key) {
        std::size_t index = findIndex(key);
        if (index != npos) {
            return m_data[index].value;
        }

        if (m_size >= m_capacity) {
            grow();
        }

        m_data[m_size] = Entry{key, Value{}};
        return m_data[m_size++].value;
    }

    void clear() {
        delete[] m_data;
        m_data = nullptr;
        m_size = 0;
        m_capacity = 0;
    }
};
