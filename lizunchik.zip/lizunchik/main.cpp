#include <iostream>
#include <string>

#ifdef _WIN32
#include <windows.h>
#endif

#include "AssocArray.h"

int main() {
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif
    AssocArray<std::string, int> ages;
    ages.insert("Алиса", 30);
    ages.insert("Боб", 25);
    ages.insert("Чарли", 28);

    std::cout << "Возрастной словарь:\n";
    for (const auto& name : {"Алиса", "Боб", "Чарли"}) {
        const int* value = ages.find(name);
        if (value) {
            std::cout << name << " = " << *value << "\n";
        }
    }

    ages.insert("Боб", 26);
    std::cout << "Обновлено значение для Боба: " << *ages.find("Боб") << "\n";
    ages.erase("Чарли");
    std::cout << "Чарли присутствует? " << (ages.contains("Чарли") ? "да" : "нет") << "\n";
    std::cout << "Текущий размер: " << ages.size() << "\n\n";

    AssocArray<int, std::string> codes;
    codes.insert(1, "один");
    codes.insert(2, "два");
    codes.insert(42, "ответ");

    std::cout << "Целочисленный словарь:\n";
    for (int key : {1, 2, 42}) {
        const std::string* value = codes.find(key);
        if (value) {
            std::cout << key << " -> " << *value << "\n";
        }
    }

    codes[3] = "три";
    std::cout << "Добавлен ключ 3 со значением: " << codes[3] << "\n";
    std::cout << "Итоговый размер: " << codes.size() << "\n";

    return 0;
}
